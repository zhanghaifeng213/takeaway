<template>
  <v-app id="app">
    <router-view></router-view>
  </v-app>
</template>

<style lang="stylus">
@import '~vuetify/src/stylus/main';
</style>