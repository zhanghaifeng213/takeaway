module.exports = {
  NODE_ENV: '"production"',
  API_ROOT: '"http://47.104.160.105:3030"',
  SOCKETIO: '"http://47.104.160.105:3030"'
}
