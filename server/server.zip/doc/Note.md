# 后端接口规范

1. 编码规范
2. 命名规范

## 相关参考资料

+ [ECMAScript 6基础](http://es6.ruanyifeng.com/#docs/class)
+ [路由设计](https://chenshenhai.github.io/koa2-note/note/project/route.html)
+ [Node.js的Koa实现JWT用户认证](https://zhuanlan.zhihu.com/p/36351714)
